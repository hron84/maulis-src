/* htoff.c
**
** Author: Maulis Adam.
**
** Dynamically disables/enables virtual cores.
**
**
** Tested only 2 socket -quad core (8 cores) intel CPU's 
**
** Copyright terms: GNU GPL v3 or newer
**
** usage: 
**     htoff [-v]
**     hton  [-v]
**     (htoff|hton) -l
*/

#define _GNU_SOURCE

#include <libgen.h> /* basename() gnu type never modifies parameter */
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <linux/limits.h> /* PATH_MAX defined here */

void errexit(int exitcode, const char *s)
{
	fprintf (stderr,"hton/htoff error exit: %s\n", s);
	exit (exitcode);
}

#define BUFFLEN 200

int main (int argc, char *argv[])
{
	int list = 0;
	int verbose = 0;
	int htoff = 0;
	int fh;
	int status;
	int i, curcpu;
	int mincpu, maxcpu;
	int anythread = 0;
	char buff[BUFFLEN];  /* you may hate it */
	char fnamebuff[PATH_MAX];
	char *p;

	if (0 == strcmp (basename (argv[0]), "htoff"))
	{
		htoff = 1; 
	}
	if (2 == argc)
	{
		if (NULL == argv[1] )
		{
			errexit (2,"argument null - confused");
		}
		if ('\0' == argv[1][0] )
		{
			errexit (2,"short argument");
		}
		if( '-' != argv[1][0] )
		{
			errexit (2,"argument not switch");
		}
		switch (argv[1][1])
		{
		case 'v':
			verbose = 1;
			break;
		case 'l':
			list = 1;
			break;
		default:
			errexit (2,"unknown switch");
			break;
		}
	} /* end if 2 == argc */

	fh = open ("/sys/devices/system/cpu/present", O_RDONLY );
	if (-1 == fh)
	{
		perror ("cannot open /sys/devices/system/cpu/present");
		errexit (2, "this is not a linux or /sys not mounted");
	}
	status = read (fh, buff, BUFFLEN);
	if (-1 == status)
	{
		perror ("cannot read from /sys/devices/system/cpu/present");
		errexit (2, "dunno what is a problem");
	}
	if (0 == status || BUFFLEN == status)
	{
		errexit (2, "mystic error I am sorry (did nothing)");
	}
	buff[status] = '\0';

	(void) close (fh);

	status = sscanf (buff, "%d-%d\n", &mincpu, &maxcpu);
	if (2 != status)
	{
		errexit (2, "cpus present info in wrong format - confused");
	}
	if (verbose)
	{
		printf("There are %d cpus (%d-%d)\n",
			maxcpu-mincpu+1, mincpu, maxcpu);
	}
	if (1 > maxcpu-mincpu + 1)
	{
		errexit(2, "bad cpu or unsupported hardware");
	}

	/*
	*
	* real cores are identified by 
	* /sys/devices/system/cpu/cpu%d/topology/physical_package_id
	* /sys/devices/system/cpu/cpu%d/topology/core_id
	*
	* if multithreading is enabled then 
	* /sys/devices/system/cpu/cpu%d/topology/thread_siblings_list
	* contains the virtual cpu numbers share the same core.
	* try to disabling everything but the first
	*/

	/* Is multithreading on? */
	for (i=mincpu; i<=maxcpu; i++)
	{
		(void) sprintf (fnamebuff,
			"/sys/devices/system/cpu/cpu%d/topology/thread_siblings_list",
			i);

		fh = open (fnamebuff, O_RDONLY);
		if (-1 == fh ){
			continue; /* may be disabled */
		}
		status = read (fh, buff, BUFFLEN);
		if (-1 == status)
		{
			perror (
"cannot read from /sys/devices/system/cpu/cpu%d/topology/thread_siblings_list");
			errexit (2, "dunno what is the problem");
		}
		if (0 == status || BUFFLEN == status)
		{
			errexit (2, "another mystic error I am sorry (did nothing)");
		}
		buff[status] = '\0';
		(void) close(fh);

		if (NULL != strrchr (buff, ','))
		{
			anythread = 1;
		}
	} /* end for i */

	if (list)
	{
		if (anythread)
		{
			puts ("HyperThreading is enabled");
		}
		else
		{
			puts ("HyperThreading is disabled");
		}
		return 0;
	} /* end list */

	if (verbose)
	{
		if (htoff)
		{
			puts ("Trying to disable HyperThreading");
		}
		else
		{
			puts("Trying to enable HyperThreading");
		}
	}

	if (htoff)
	{
		if (0 == anythread)
		{
			errexit (1, "Nothing to do");
		}
		for (i=mincpu; i<maxcpu+1; i++)
		{

			/* must ensure this cpu are online but I do not
			   want to access more one file... */
			(void) sprintf (fnamebuff,
				"/sys/devices/system/cpu/cpu%d/topology/thread_siblings_list",
				i);

			/* If not accessible this cpu might be offline. */ 
			fh = open(fnamebuff, O_RDONLY);
			if (-1 == fh)
			{
				continue;
			}

			status = read (fh, buff, BUFFLEN);
			if (-1 == status)
			{
				perror(
"cannot read from /sys/devices/system/cpu/cpu%d/topology/thread_siblings_list");
				errexit (2, "dunno what is a problem");
			}
			if (0 == status || BUFFLEN == status)
			{
				errexit (2, "something another mistic error I'm sorry (did nothing)");
			}

			close(fh);

			for(p=strchr(buff, ','); p!=NULL; p=strchr(p, ','))
			{
				p++;
				curcpu = atoi(p);
				(void) sprintf (fnamebuff,
					"/sys/devices/system/cpu/cpu%d/online",
					curcpu);

				fh = open (fnamebuff, O_WRONLY);
				if (-1 == fh)
				{
					perror ("cannot open given file");
					errexit (2, fnamebuff);
				}
				if (verbose)
				{
					printf("disabling CPU%d\n",curcpu);
				}
				status = write (fh,"0\n",2);
				if (-1 == status)
				{
					perror ("cannot disable this vcore: write() said");
					errexit(2, "Give up");
				}
				close(fh);
			} /* end for p */
		} /* end for i */
	}
	else
	{

		/* ht on. */
		anythread =0 ;
		for (i=mincpu+1; i<=maxcpu; i++)
		{

			/* The first cpu is always online. */
			(void) sprintf (fnamebuff,
				"/sys/devices/system/cpu/cpu%d/online", i);
			fh = open (fnamebuff, O_RDWR);
			if (-1 == fh)
			{
				perror("cannot open given file");
				errexit(2, fnamebuff);
			}
			status = read (fh, buff, BUFFLEN);
			if(-1 == status)
			{
				perror ("cannot read from /sys/devices/system/cpu%d/online");
				errexit(2, "dunno what is a problem");
			}
			if (0 == status || BUFFLEN == status)
			{
				errexit (2, "something third mistic error I'm sorry (did nothing)");
			}
			if (0 == strncmp (buff,"0",1))
			{

				/* Offline. */
				if (verbose)
				{
					printf ("enabling CPU%d\n", i);
				}
				status = pwrite (fh, "1\n", 2, 0);
				if (-1 == status)
				{
					perror("cannot enable this vcore: write() said");
					errexit(2, "Give up");
				}
				anythread = 1;
			}
			(void) close(fh);
		} /* end for i */
		if( 0 == anythread )
		{
			errexit (1, "Nothing to do");
		}

	} /* end if htoff/hton */
	return 0;
}

